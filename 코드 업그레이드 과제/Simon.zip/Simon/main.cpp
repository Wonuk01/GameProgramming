#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <cmath>
#include <optional>
#include <cstdint>

// 상수 정의
const int WINDOW_WIDTH = 800;
const int WINDOW_HEIGHT = 600;
const int MAX_LEVEL = 10;
const int NUM_KEYS = 4;

// 음계 주파수 계산
int calcFrequency(int octave, int inx) {
    double doScale = 32.7032;
    double ratio = std::pow(2.0, 1.0 / 12.0);
    double temp = doScale * std::pow(2, octave - 1);
    
    for (int i = 0; i < inx; i++) {
        temp = static_cast<int>(temp + 0.5);
        temp *= ratio;
    }
    return static_cast<int>(temp);
}

// 사운드 버퍼 생성 (비프음 생성)
sf::SoundBuffer createBeepSound(int frequency, float duration) {
    const unsigned SAMPLE_RATE = 44100;
    const unsigned sampleCount = static_cast<unsigned>(SAMPLE_RATE * duration);
    
    // SFML 3.0에서는 std::int16_t 사용
    std::int16_t* samples = new std::int16_t[sampleCount];
    const double increment = frequency * 2 * 3.14159 / SAMPLE_RATE;
    double x = 0;
    
    for (unsigned i = 0; i < sampleCount; i++) {
        samples[i] = static_cast<std::int16_t>(32760 * std::sin(x));
        x += increment;
    }
    
    sf::SoundBuffer buffer;
    // SFML 3.0에서는 채널 정보도 필요
    std::vector<sf::SoundChannel> channels = {sf::SoundChannel::Mono};
    buffer.loadFromSamples(samples, sampleCount, 1, SAMPLE_RATE, channels);
    delete[] samples;
    
    return buffer;
}

// 게임 상태
enum class GameState {
    Menu,
    ShowPattern,
    PlayerInput,
    LevelComplete,
    GameOver,
    Victory
};

class SimonGame {
private:
    sf::RenderWindow window;
    std::vector<int> pattern;
    int currentLevel;
    int userIndex;
    GameState state;
    
    // UI 요소
    sf::RectangleShape keys[NUM_KEYS];
    sf::Font font;
    sf::Text titleText, levelText, messageText;
    
    // 사운드
    sf::SoundBuffer soundBuffers[NUM_KEYS];
    sf::Sound sound;
    
    // 타이밍
    sf::Clock clock;
    float patternDelay;
    int patternIndex;
    
    // 애니메이션
    int highlightedKey;
    float highlightProgress;
    sf::Clock highlightClock;
    
    // 색상
    sf::Color keyColors[NUM_KEYS];
    sf::Color keyHighlight[NUM_KEYS];
    std::string keyLabels[NUM_KEYS];
    
    // 음계 인덱스 (도=0, 미=4, 솔=7, 옥타브도=12)
    int noteIndices[NUM_KEYS] = {0, 4, 7, 12};
    
public:
    SimonGame() : window(sf::VideoMode({WINDOW_WIDTH, WINDOW_HEIGHT}), "Simon Game - SFML"),
                  currentLevel(1), userIndex(0), state(GameState::Menu),
                  titleText(font), levelText(font), messageText(font), // SFML 3에서는 폰트 필수
                  sound(soundBuffers[0]), // 더미 버퍼로 초기화
                  patternDelay(0), patternIndex(0),
                  highlightedKey(-1), highlightProgress(0) {
        
        std::srand(static_cast<unsigned>(std::time(nullptr)));
        
        // 폰트 로드 (시스템 폰트 사용)
        const std::string ARIAL_FONT = "arial.ttf";
        const std::string MALGUN_FONT = "malgun.ttf";

        if (!font.openFromFile(MALGUN_FONT)) {
            std::cout << "한글 폰트 로드 실패. Arial 시도..." << std::endl;
            if (!font.openFromFile(ARIAL_FONT)) {
                std::cerr << "폰트를 찾을 수 없습니다!" << std::endl;
            }
        }
        
        // 텍스트 설정
        titleText.setString("Simon Game");
        titleText.setCharacterSize(32);
        titleText.setFillColor(sf::Color::White);
        titleText.setPosition(sf::Vector2f(50, 30));
        
        levelText.setCharacterSize(24);
        levelText.setFillColor(sf::Color::White);
        levelText.setPosition(sf::Vector2f(50, 100));
        
        messageText.setCharacterSize(20);
        messageText.setFillColor(sf::Color::Yellow);
        messageText.setPosition(sf::Vector2f(50, 500));
        
        // 건반 색상 설정
        keyColors[0] = sf::Color(100, 150, 255); // 파란색
        keyColors[1] = sf::Color(100, 255, 150); // 초록색
        keyColors[2] = sf::Color(255, 200, 100); // 주황색
        keyColors[3] = sf::Color(255, 100, 150); // 분홍색
        
        for (int i = 0; i < NUM_KEYS; i++) {
            keyHighlight[i] = sf::Color(
                std::min(255, keyColors[i].r + 100),
                std::min(255, keyColors[i].g + 100),
                std::min(255, keyColors[i].b + 100)
            );
        }
        
        // 건반 위치 및 크기 설정
        float keyWidth = 150;
        float keyHeight = 200;
        float spacing = 20;
        float startX = (WINDOW_WIDTH - (keyWidth * NUM_KEYS + spacing * (NUM_KEYS - 1))) / 2;
        float startY = 200;
        
        for (int i = 0; i < NUM_KEYS; i++) {
            keys[i].setSize(sf::Vector2f(keyWidth, keyHeight));
            keys[i].setPosition(sf::Vector2f(startX + i * (keyWidth + spacing), startY));
            keys[i].setFillColor(keyColors[i]);
            keys[i].setOutlineThickness(3);
            keys[i].setOutlineColor(sf::Color::White);
        }
        
        // 사운드 버퍼 생성
        for (int i = 0; i < NUM_KEYS; i++) {
            int freq = calcFrequency(4, noteIndices[i]);
            soundBuffers[i] = createBeepSound(freq, 0.35f);
        }
    }
    
    void run() {
        while (window.isOpen()) {
            handleEvents();
            update();
            render();
        }
    }
    
private:
    void handleEvents() {
        // SFML 3.0의 새로운 이벤트 처리 방식
        while (std::optional<sf::Event> event = window.pollEvent()) {
            // Closed 이벤트
            if (event->is<sf::Event::Closed>()) {
                window.close();
            }
            
            // KeyPressed 이벤트
            if (const auto* keyPressed = event->getIf<sf::Event::KeyPressed>()) {
                if (state == GameState::Menu) {
                    startGame();
                } else if (state == GameState::PlayerInput) {
                    handlePlayerInput(keyPressed->code);
                } else if (state == GameState::GameOver || state == GameState::Victory) {
                    if (keyPressed->code == sf::Keyboard::Key::Space) {
                        resetGame();
                    } else if (keyPressed->code == sf::Keyboard::Key::Escape) {
                        window.close();
                    }
                } else if (state == GameState::LevelComplete) {
                    nextLevel();
                }
            }
            
            // MouseButtonPressed 이벤트
            if (const auto* mousePressed = event->getIf<sf::Event::MouseButtonPressed>()) {
                if (state == GameState::PlayerInput) {
                    handleMouseInput(mousePressed->position.x, mousePressed->position.y);
                }
            }
        }
    }
    
    void handlePlayerInput(sf::Keyboard::Key key) {
        int keyIndex = -1;
        
        if (key == sf::Keyboard::Key::Num1 || key == sf::Keyboard::Key::Numpad1) keyIndex = 0;
        else if (key == sf::Keyboard::Key::Num2 || key == sf::Keyboard::Key::Numpad2) keyIndex = 1;
        else if (key == sf::Keyboard::Key::Num3 || key == sf::Keyboard::Key::Numpad3) keyIndex = 2;
        else if (key == sf::Keyboard::Key::Num4 || key == sf::Keyboard::Key::Numpad4) keyIndex = 3;
        
        if (keyIndex >= 0) {
            checkInput(keyIndex);
        }
    }
    
    void handleMouseInput(int x, int y) {
        for (int i = 0; i < NUM_KEYS; i++) {
            if (keys[i].getGlobalBounds().contains(sf::Vector2f(static_cast<float>(x), static_cast<float>(y)))) {
                checkInput(i);
                break;
            }
        }
    }
    
    void checkInput(int keyIndex) {
        playSound(keyIndex);
        startHighlight(keyIndex);
        
        if (pattern[userIndex] == keyIndex + 1) {
            userIndex++;
            if (userIndex >= currentLevel) {
                state = GameState::LevelComplete;
                messageText.setString("Level " + std::to_string(currentLevel) + " Clear! Press any key to continue.");
            }
        } else {
            state = GameState::GameOver;
            messageText.setString("Game Over! Final Level: " + std::to_string(currentLevel) + 
                                "\nSpace: Restart  |  ESC: Exit");
        }
    }
    
    void update() {
        // 건반 하이라이트 애니메이션 업데이트
        if (highlightedKey >= 0) {
            float elapsed = highlightClock.getElapsedTime().asSeconds();
            
            // 0.3초 동안 페이드 인/아웃
            if (elapsed < 0.15f) {
                // 페이드 인
                highlightProgress = elapsed / 0.15f;
            } else if (elapsed < 0.3f) {
                // 페이드 아웃
                highlightProgress = 1.0f - ((elapsed - 0.15f) / 0.15f);
            } else {
                // 애니메이션 종료
                highlightedKey = -1;
                highlightProgress = 0;
            }
            
            // 색상 보간
            if (highlightedKey >= 0 && highlightedKey < NUM_KEYS) {
                sf::Color baseColor = keyColors[highlightedKey];
                sf::Color highlightColor = keyHighlight[highlightedKey];
                
                sf::Color currentColor(
                static_cast<std::uint8_t>(baseColor.r + (highlightColor.r - baseColor.r) * highlightProgress),
                static_cast<std::uint8_t>(baseColor.g + (highlightColor.g - baseColor.g) * highlightProgress),
                static_cast<std::uint8_t>(baseColor.b + (highlightColor.b - baseColor.b) * highlightProgress)
                );
                
                keys[highlightedKey].setFillColor(currentColor);
            }
        }
        
        if (state == GameState::ShowPattern) {
            if (clock.getElapsedTime().asSeconds() >= patternDelay) {
                if (patternIndex < currentLevel) {
                    int keyIndex = pattern[patternIndex] - 1;
                    playSound(keyIndex);
                    startHighlight(keyIndex);
                    patternIndex++;
                    patternDelay = clock.getElapsedTime().asSeconds() + 0.6f;
                } else {
                    state = GameState::PlayerInput;
                    userIndex = 0;
                    messageText.setString("Your turn! Press 1, 2, 3, 4 or click the keys.");
                }
            }
        }
    }
    
    void render() {
        window.clear(sf::Color(30, 30, 50));
        
        if (state == GameState::Menu) {
            renderMenu();
        } else {
            renderGame();
        }
        
        window.display();
    }
    
    void renderMenu() {
        sf::Text menuTitle(font);
        menuTitle.setString("Simon Game");
        menuTitle.setCharacterSize(40);
        menuTitle.setFillColor(sf::Color::White);
        menuTitle.setPosition(sf::Vector2f(100, 150));
        
        sf::Text instructions(font);
        instructions.setString(
            "How to play:\n\n"
            "1. Watch and listen to the pattern\n"
            "2. Repeat the pattern using 1, 2, 3, 4 keys or mouse\n"
            "3. Pattern gets longer each level\n\n"
            "Press any key to start"
        );
        instructions.setCharacterSize(24);
        instructions.setFillColor(sf::Color(200, 200, 200));
        instructions.setPosition(sf::Vector2f(100, 250));
        
        window.draw(menuTitle);
        window.draw(instructions);
    }
    
    void renderGame() {
        window.draw(titleText);
        
        levelText.setString("Level: " + std::to_string(currentLevel) + " / " + std::to_string(MAX_LEVEL));
        window.draw(levelText);
        
        for (int i = 0; i < NUM_KEYS; i++) {
            window.draw(keys[i]);
            
            sf::Text label(font);
            label.setString(keyLabels[i]);
            label.setCharacterSize(20);
            label.setFillColor(sf::Color::Black);
            
            sf::FloatRect textBounds = label.getLocalBounds();
            // SFML 3.0에서는 getSize() 대신 size 멤버 사용
            label.setPosition(sf::Vector2f(
                keys[i].getPosition().x + (keys[i].getSize().x - textBounds.size.x) / 2,
                keys[i].getPosition().y + keys[i].getSize().y / 2 - 10
            ));
            
            window.draw(label);
        }
        
        window.draw(messageText);
    }
    
    void startGame() {
        state = GameState::ShowPattern;
        currentLevel = 1;
        pattern.clear();
        addToPattern();
        patternIndex = 0;
        clock.restart();
        patternDelay = 1.0f;
        messageText.setString("Watch and listen carefully!");
    }
    
    void addToPattern() {
        pattern.push_back((std::rand() % NUM_KEYS) + 1);
    }
    
    void nextLevel() {
        currentLevel++;
        if (currentLevel > MAX_LEVEL) {
            state = GameState::Victory;
            messageText.setString("Congratulations! You completed all levels!\nSpace: Restart  |  ESC: Exit");
        } else {
            addToPattern();
            state = GameState::ShowPattern;
            patternIndex = 0;
            clock.restart();
            patternDelay = 1.0f;
            messageText.setString("Watch and listen carefully!");
        }
    }
    
    void resetGame() {
        startGame();
    }
    
    void playSound(int keyIndex) {
        sound.setBuffer(soundBuffers[keyIndex]);
        sound.play();
    }
    
    void startHighlight(int keyIndex) {
        highlightedKey = keyIndex;
        highlightProgress = 0;
        highlightClock.restart();
    }
};

int main() {
    SimonGame game;
    game.run();
    return 0;
}